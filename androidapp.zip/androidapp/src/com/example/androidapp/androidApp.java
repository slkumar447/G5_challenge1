package com.example.androidapp;
import java.io.*;
import java.text.*;
import java.util.*;
import android.*;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.TextView;

import com.example.slkhbaseapp.R;
import com.jcraft.*;

public class androidApp extends ActionBarActivity {
	
	private String twitterDataText;
	WebView webViewData;
	Button buttn3;
	
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
				 
		
		Button buttn3 =(Button) findViewById(R.id.buttn3);
		buttn3.setOnClickListener(new OnClickListener() {
 
			@Override
			public void onClick(View arg0) {
				FileInputStream textFile;
				try{
					File f1 = new File(Environment.getExternalStorageDirectory()+"/tweetFile/finalTweetSentimentData.txt");
					if(f1.exists()==true){
						textFile = new FileInputStream(f1);
						BufferedReader bufferr = new BufferedReader(new FileReader(f1));
						String lineText;
						String data=new String();
						 String temp1 = "";
						 while((lineText = bufferr.readLine())!=null)
						 {
							 temp1 = lineText;
							 data=data.concat(temp1+"\n");
							 						
						 }
						 twitterDataText=data;
						 
						 TextView viewtxt=(TextView)findViewById(R.id.Viewtext);
						 viewtxt.setText(data);
						 textFile.close();
						bufferr.close();
					}
					else{
						
					}		
					
				}
				catch(Exception e){
					System.out.println(e.toString());
				}
			}
 
		});
		

		Button buttn4 =(Button) findViewById(R.id.buttn4);
		buttn4.setOnClickListener(new OnClickListener() {
 
			@Override
			public void onClick(View arg0) {
				
				int x=0;
				int y=0;				   		   
					   		   StringTokenizer st = new StringTokenizer(twitterDataText,"/");
					   		   while (st.hasMoreTokens()) {			   			   
					   			   String compare=st.nextToken();
					   			  
					   			   if(compare.contains("positive")){
					   				   	 x++;
					    			   }
					   			   else if(compare.contains("negative")){
					   				   y++;
					   				 					   			   }			   	
					   			}
			 String op=new String("PositiveTweets are : "+x+"\t"+" NegativeTweets are  : "+y);		   		 
				 TextView viewtext=(TextView)findViewById(R.id.Viewtext);
				 viewtext.setText(op);
				}
 
		});

	}
}
	
	 